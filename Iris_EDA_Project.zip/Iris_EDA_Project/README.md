# Iris_EDA_Project

This project performs EDA on the Iris dataset.
