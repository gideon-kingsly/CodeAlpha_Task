
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import datasets
import numpy as np
import os

out_dir = "plots"
os.makedirs(out_dir, exist_ok=True)

iris = datasets.load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['target'] = iris.target
df['target_name'] = df['target'].map(dict(enumerate(iris.target_names)))

df.to_csv("iris_dataset.csv", index=False)

print("Shape:", df.shape)
print("\nData types:\n", df.dtypes)
print("\nFirst 5 rows:\n", df.head().to_string(index=False))
print("\nMissing values per column:\n", df.isnull().sum())
print("\nSummary statistics:\n", df.describe().T)

corr = df.iloc[:, :4].corr()
print("\nCorrelation matrix:\n", corr)

# hist plots
for col in ["sepal length (cm)", "sepal width (cm)"]:
    plt.figure()
    df[col].hist()
    plt.title(f"Histogram - {col}")
    plt.xlabel(col); plt.ylabel("Count")
    plt.savefig(os.path.join(out_dir, f"hist_{col.replace(' ','_').replace('(','').replace(')','')}.png"))
    plt.close()

# scatter
plt.figure()
plt.scatter(df['sepal length (cm)'], df['sepal width (cm)'])
plt.title("Scatter - sepal length vs sepal width")
plt.xlabel("sepal length (cm)")
plt.ylabel("sepal width (cm)")
plt.savefig(os.path.join(out_dir, "scatter_sepal_len_width.png"))
plt.close()

# correlation matrix
plt.figure()
plt.imshow(corr, interpolation='nearest')
plt.title("Correlation matrix")
plt.xticks(range(len(corr.columns)), corr.columns, rotation=45, ha='right')
plt.yticks(range(len(corr.columns)), corr.columns)
for (i,j), val in np.ndenumerate(corr.values):
    plt.text(j,i,f"{val:.2f}",ha='center',va='center')
plt.colorbar()
plt.tight_layout()
plt.savefig(os.path.join(out_dir, "correlation_matrix.png"))
plt.close()

# boxplots
for feat in df.columns[:4]:
    plt.figure()
    df[feat].plot(kind='box')
    plt.title(f"Boxplot - {feat}")
    safe=feat.replace(' ','_').replace('(','').replace(')','')
    plt.savefig(os.path.join(out_dir, f"boxplot_{safe}.png"))
    plt.close()

print("Plots generated in ./plots")
