    # Sentiment Analysis with LSTM (Project - CodeAlpha Internship)

    ## Overview

    This project demonstrates a **deep learning** approach to sentiment analysis using an **LSTM (Bidirectional LSTM)** model. It includes:

    - `reviews_200.csv` — synthetic dataset (200 labeled reviews)

    - `train_lstm.py` — training script (Keras / TensorFlow)

    - `predict.py` — inference script to predict sentiment for new texts

    - `requirements.txt` — Python dependencies

    - `Task4_Presentation_Gideon.pptx` — presentation slides


## Quick Start (local machine)

1. Create & activate virtual environment

```bash
python -m venv venv
# macOS/Linux
source venv/bin/activate
# Windows (PowerShell)
.\\venv\\Scripts\\Activate.ps1
```

2. Install dependencies

```bash
pip install -r requirements.txt
```

3. Train the model (example)

```bash
python train_lstm.py --data reviews_200.csv --epochs 8 --batch_size 32
```

> Training will save artifacts in `./artifacts` including the tokenizer and best model.

4. Predict on new text

```bash
python predict.py "This product is amazing and I love it"
```

## Notes & Tips
- For realistic training on larger datasets, use a machine with GPU or Google Colab.
- You can adjust `--vocab_size`, `--max_len`, `--embedding_dim` in the training script.

## Author
Gideon Kingsly Raj R

---
