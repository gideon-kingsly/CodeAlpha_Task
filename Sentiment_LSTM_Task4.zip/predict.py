# predict.py
# Load tokenizer + model and predict sentiment for new texts.
#
# Usage:
#   python predict.py "This product is great!"
#
import sys, pickle, numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences

if len(sys.argv) < 2:
    print("Usage: python predict.py "Your text here"")
    sys.exit(1)

text = sys.argv[1]
# Load artifacts
tokenizer = pickle.load(open('artifacts/tokenizer.pkl','rb'))
label_map = eval(open('artifacts/label_map.txt','r').read())
inv_label_map = {v:k for k,v in label_map.items()}

seq = tokenizer.texts_to_sequences([text])
seq = pad_sequences(seq, maxlen=100, padding='post', truncating='post')
model = load_model('artifacts/best_lstm_model.h5')
preds = model.predict(seq)
pred_label = inv_label_map[int(np.argmax(preds, axis=1)[0])]
print(f'Input: {text}\nPredicted sentiment: {pred_label}')

