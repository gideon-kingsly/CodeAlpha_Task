# train_lstm.py
# Train an LSTM-based sentiment classifier on the provided CSV dataset.
# NOTE: Training may require a machine with sufficient RAM/CPU; GPUs are optional.
#
# Usage:
#   python -m venv venv
#   source venv/bin/activate   # or .\venv\Scripts\Activate.ps1 on Windows
#   pip install -r requirements.txt
#   python train_lstm.py --data reviews_200.csv --epochs 8 --batch_size 32
#
import argparse
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
import os

parser = argparse.ArgumentParser()
parser.add_argument('--data', default='reviews_200.csv')
parser.add_argument('--max_len', type=int, default=100)
parser.add_argument('--vocab_size', type=int, default=5000)
parser.add_argument('--embedding_dim', type=int, default=100)
parser.add_argument('--epochs', type=int, default=8)
parser.add_argument('--batch_size', type=int, default=32)
args = parser.parse_args()

df = pd.read_csv(args.data)
texts = df['review_text'].astype(str).tolist()
labels = df['sentiment'].astype(str).tolist()

# Encode labels
le = LabelEncoder()
y = le.fit_transform(labels)
# Save label encoder mapping
label_map = dict(zip(le.classes_, le.transform(le.classes_)))
os.makedirs('artifacts', exist_ok=True)
with open('artifacts/label_map.txt','w') as f:
    f.write(str(label_map))

# Tokenize texts
tokenizer = Tokenizer(num_words=args.vocab_size, oov_token='<OOV>')
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
X = pad_sequences(sequences, maxlen=args.max_len, padding='post', truncating='post')

# Save tokenizer
import pickle
with open('artifacts/tokenizer.pkl','wb') as f:
    pickle.dump(tokenizer, f)

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

model = Sequential()
model.add(Embedding(input_dim=args.vocab_size, output_dim=args.embedding_dim, input_length=args.max_len))
model.add(Bidirectional(LSTM(64, return_sequences=False)))
model.add(Dropout(0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.3))
model.add(Dense(len(np.unique(y)), activation='softmax'))

model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

callbacks = [
    EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True),
    ModelCheckpoint('artifacts/best_lstm_model.h5', save_best_only=True, monitor='val_loss')
]

history = model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=args.epochs, batch_size=args.batch_size, callbacks=callbacks)

# Save final model
model.save('artifacts/final_lstm_model.h5')

# Save training history to CSV
import pandas as pd
hist_df = pd.DataFrame(history.history)
hist_df.to_csv('artifacts/training_history.csv', index=False)
print('Training complete. Artifacts saved to ./artifacts')

