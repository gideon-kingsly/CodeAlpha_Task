import pandas as pd
import matplotlib.pyplot as plt
import os

df = pd.read_csv("netflix_100_rows.csv")
os.makedirs("plots", exist_ok=True)

df["type"].value_counts().plot(kind="bar")
plt.title("Count of Movies vs TV Shows")
plt.savefig("plots/bar_type.png"); plt.close()

df["rating"].value_counts().plot(kind="pie", autopct="%1.1f%%")
plt.title("Rating Distribution")
plt.savefig("plots/pie_rating.png"); plt.close()

df.sort_values("release_year")["release_year"].reset_index(drop=True).plot(kind="line")
plt.title("Release Year Trend")
plt.savefig("plots/line_years.png"); plt.close()

plt.scatter(range(len(df)), df["release_year"])
plt.title("Scatter Plot – Release Year")
plt.savefig("plots/scatter_years.png"); plt.close()

df["release_year"].hist()
plt.title("Histogram – Release Years")
plt.savefig("plots/hist_years.png"); plt.close()

df["release_year"].plot(kind="box")
plt.title("Boxplot – Release Years")
plt.savefig("plots/box_years.png"); plt.close()

df["country"].value_counts().plot(kind="bar")
plt.title("Shows Per Country")
plt.savefig("plots/bar_country.png"); plt.close()

print("Task 3 visualizations generated.")
