# Task 3 – Data Visualization (Netflix 100 Rows Dataset)

This project demonstrates data visualization using a 100-row Netflix dataset.

## Included Visualizations
1. Bar Chart – Movies vs TV Shows
2. Pie Chart – Rating Distribution
3. Line Chart – Release Year Trend
4. Scatter Plot – Release Year
5. Histogram – Release Years
6. Boxplot – Release Years
7. Bar Chart – Shows Per Country

## Run Instructions
```bash
pip install pandas matplotlib
python task3_visualization.py
```

## Author
Gideon Kingsly Raj R
